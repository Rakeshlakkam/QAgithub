package Seleniumsession;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class CS7 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
       ChromeOptions options = new ChromeOptions();
		WebDriver d = new ChromeDriver(options);
		d.get("https://www.spicejet.com/");
		d.manage().window().maximize();
		Thread.sleep(5000);
	   options.addArguments("--disable-notifications");
	   WebElement fromCountry = d.findElement(By.xpath("//div[contains(text(), 'From')]"));
	   fromCountry.sendKeys("Hydera");
	   Thread.sleep(2000);
	   WebElement toCountry = d.findElement(By.xpath("//div[@class='css-1dbjc4n r-13awgt0 r-18u37iz']/div[3]/div/div[2]/input"));
	   toCountry.sendKeys("GOA");
		d.findElement(By.xpath("//div[@class='css-1dbjc4n r-19h5ruw r-136ojw6']/div/div[2]/div[2]/div[3]/div[2]/div/div[1]/div/div[3]/div[5]/div[1]/div")).click();
		d.findElement(By.xpath("//div[@class='css-1dbjc4n']/div[contains(text(), 'Senior Citizen')]")).click();
		d.findElement(By.xpath("//div[@id='react-root']/div/div/div[1]/div[3]/div[2]/div[7]/div[2]/div[1]")).click();
		Thread.sleep(3000);
		String displayed = d.findElement(By.xpath("//*[@class='css-1dbjc4n r-13awgt0 r-18u37iz r-1wtj0ep r-tv6buo']/div")).getText();
		String expected = "Senior Citizen";
		System.out.println(displayed);
		if (displayed.contains(expected))
			{
				System.out.println("PASS");
			}
			else
			{
				System.out.println("Fail");
			}
            d.findElement(By.xpath("((//div[@class='css-1dbjc4n r-zso239'])[4]/*/*/*)[1]")).click();
            d.findElement(By.xpath("(//div[@class='css-1dbjc4n r-13awgt0 r-18u37iz'])[2]/div[3]/div")).click();
        	d.quit();

	}

}
