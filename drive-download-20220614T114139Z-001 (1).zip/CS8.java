package Seleniumsession;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CS8 {

	public static void main(String[] args) throws InterruptedException 
	{	
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("https://jqueryui.com/droppable/");
		driver.manage().window().maximize();
		Thread.sleep(5000);
		String Droppable = driver.findElement(By.className("entry-title")).getText();
		System.out.println(Droppable);
		int size = driver.findElements(By.tagName("iframe")).size();
		System.out.println(size);
		driver.switchTo().frame(driver.findElement(By.className("demo-frame")));
		Actions mover = new Actions(driver);
		WebElement target = driver.findElement(By.id("droppable"));
		WebElement pickup = driver.findElement(By.id("draggable"));
		mover.dragAndDrop(pickup,target).build().perform();
		System.out.println(Droppable);
		Thread.sleep(3000);
		driver.quit();
	}

}
