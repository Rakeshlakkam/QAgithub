package Seleniumsession;

import java.util.Scanner;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class CS1 {

	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter your browser name: ");
		String browser = input.nextLine();
		
		if(browser.equalsIgnoreCase("Chrome"))
		{
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("https://www.facebook.com/");
		String Output=d.getTitle();
		String Input="Facebook � log in or sign up";
		if(Input.equals(Output))
		{
		System.out.println("Launched chrome browser. Title Verified and  Pass");
		}
		else
		{
		System.out.println("Launched chrome browser. Title not Verified and Fail");
		}
		d.close();
		}
		else
		{
		if (browser.equalsIgnoreCase("Edge"))
		{
		System.setProperty("webdriver.edge.driver","D:\\Selenium\\Softwares\\msedgedriver.exe");
		WebDriver driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.facebook.com");
		String Output=driver.getTitle();
		String Input="Facebook � log in or sign up";
		if(Input.equals(Output))
		{
		System.out.println("Launched chrome browser. Title Verified and  Pass");
		}
		else
		{
		System.out.println("Launched chrome browser. Title not Verified and Fail");
		}
		driver.close();
		}
		else
		{
		System.out.println("Your browser is not supported");
		}
		
		}
		}
		}
