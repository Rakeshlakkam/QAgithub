package Seleniumsession;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class CS6 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("http://www.youcandealwithit.com/");
		Thread.sleep(5000);
		Actions Mhover = new Actions(d);
		Mhover.moveToElement(d.findElement(By.linkText("BORROWERS"))).perform();
		d.findElement(By.linkText("Calculators & Resources")).click();
		d.findElement(By.linkText("Calculators")).click();
		d.findElement(By.linkText("Budget Calculator")).click();
		d.findElement(By.xpath("//div[@class=\"calcWrapper\"]/div[2]/div[1]/input")).sendKeys("300");
		d.findElement(By.xpath("//div[@class=\"calcWrapper\"]/div[2]/div[2]/input")).sendKeys("100");
		d.findElement(By.xpath("//div[@class=\"calcWrapper\"]/div[2]/div[3]/input")).sendKeys("200");
		d.findElement(By.xpath("//div[@class=\"calcWrapper\"]/div[4]/div[1]/input")).sendKeys("2000");
		d.findElement(By.xpath("//div[@class=\"calcWrapper\"]/div[4]/div[2]/input")).sendKeys("200");
		WebElement tmonthly = d.findElement(By.xpath("//div[@class='calcWrapper']/div[5]/div[4]/input"));
		String TotalMonthly = tmonthly.getAttribute("value");
		System.out.println("Total Monthly Income is :"+TotalMonthly);
		WebElement MoExpence = d.findElement(By.xpath("//div[@class='calcWrapper']/div[5]/div[2]/input"));
		String MonthlyExpence = MoExpence.getAttribute("value");
		System.out.println("Total Monthly Expence is :"+MonthlyExpence);
		WebElement UO = d.findElement(By.xpath("//div[@class='calcWrapper']/div[5]/div[5]/input"));
		String UOBudget = UO.getAttribute("value");
		System.out.println("Total Monthly Income is :"+UOBudget);
		float TME= Float.parseFloat(TotalMonthly);
		System.out.println(TME);
		float ME=Float.parseFloat(MonthlyExpence);
		System.out.println(ME);
		
		if(TME>ME){
			System.out.println("your savings are amazing");
			
		}
		else
		{
			System.out.println("You need to improve in savings");
		}
		d.quit();
		
	}

}
