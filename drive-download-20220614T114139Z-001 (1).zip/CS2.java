package Seleniumsession;

import java.util.logging.Level;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CS2 {

	public static void main(String[] args) {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		java.util.logging.Logger.getLogger ("org.openqa.selenium").setLevel (Level.OFF);
		System.setProperty ("webdriver.chrome.silentOutput", "true");
		WebDriver d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("https://www.facebook.com/");
		System.out.println("Title is "+d.getTitle());
		d.close();
		
	}

}
