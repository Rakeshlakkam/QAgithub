package Seleniumsession;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class CS4 {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("https://www.linkedin.com/");
        d.findElement(By.className("sign-in-form__forgot-password-link")).click();
        String ForgotPassword = d.getTitle();
		if(ForgotPassword.equalsIgnoreCase("Reset Password | LinkedIn"))
		{
			System.out.println("Pass : ");
			System.out.println(ForgotPassword);
			
		}
		else 
		{
			System.out.println("Failed to load the screen");
			
		}
		d.findElement(By.linkText("Join now")).click();
		String JoinLink = d.getTitle();
		if(JoinLink.equalsIgnoreCase("Sign Up | LinkedIn"))
		{
			System.out.println("Pass : ");
			System.out.println(JoinLink);
			
		}
		else 
		{
			System.out.println("Failed to load the screen");
			
		}
		d.findElement(By.linkText("Sign in")).click();
		String Signin = d.getTitle();
		if(Signin.equalsIgnoreCase("LinkedIn Login, Sign in | LinkedIn"))
		{
			System.out.println("Pass : ");
			System.out.println(Signin);
			
		}
		else 
		{
			System.out.println("Failed to load the screen");
			
		}
		
		d.findElement(By.name("session_key")).sendKeys("adminaccount");
		d.findElement(By.id("password")).sendKeys("12345");
		d.findElement(By.xpath("/html/body/div[1]/main/div[2]/div[1]/form/div[3]/button\r\n"
				+ "")).click();
		
		String login = d.getTitle();
		if(login.equalsIgnoreCase("Please enter a valid username"))
				{
			System.out.println("Login Failed");
				}
		else 
		{
			System.out.println("PASS");
			
		}
     d.close();

	}

}
