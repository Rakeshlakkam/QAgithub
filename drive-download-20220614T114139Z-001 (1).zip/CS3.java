package Seleniumsession;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CS3 {

	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		WebDriver d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("https://www.facebook.com/");
        d.findElement(By.id("email")).sendKeys("samsaravananr");
        d.findElement(By.id("pass")).sendKeys("12345");
        d.findElement(By.name("login")).click();
        Thread.sleep(5000);
        String expected = "The password that you've entered is incorrect.";
		
		WebElement actual = d.findElement(By.className("_9ay7"));
	    String actualdata = actual.getText();
        if (actualdata.contains(expected))
	    {
	    	System.out.println("PASS");
	    	System.out.println("The error message is : "+actualdata);
	    }
	    else
	    {
	    	System.out.println("FAIL");
	    }
	    d.quit();
	}

}

