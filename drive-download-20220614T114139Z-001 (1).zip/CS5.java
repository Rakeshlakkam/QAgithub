package Seleniumsession;

import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.logging.Level;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class CS5 {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver","D:\\Selenium\\Softwares\\chromedriver.exe");
		java.util.logging.Logger.getLogger ("org.openqa.selenium").setLevel (Level.OFF);
		System.setProperty ("webdriver.chrome.silentOutput", "true");
		WebDriver d=new ChromeDriver();
		d.manage().window().maximize();
		d.get("https://www.google.com/");
		Thread.sleep(10000);
        List<WebElement> links = d.findElements(By.tagName("a"));
        System.out.println("No of links are "+ links.size());
        
		int validUrlCount=0;
		for(int i=0;i<links.size();i++)
        {
            WebElement E1= links.get(i);
            String url= E1.getAttribute("href");
            String linktextvalue = E1.getText();
            System.out.println(linktextvalue);
            validUrlCount = validUrlCount+1;
            verifyLinks(url);
	    }
	      System.out.println("Number of valid Urls count is :"+validUrlCount);
	d.quit();
	}
	public static void verifyLinks(String linkUrl)
    {
        try
        {
            URL url = new URL(linkUrl);
            HttpURLConnection httpURLConnect=(HttpURLConnection)url.openConnection();
            httpURLConnect.setConnectTimeout(5000);
            httpURLConnect.connect();
            if(httpURLConnect.getResponseCode()>=400)
            {
            	System.out.println(linkUrl+" - "+httpURLConnect.getResponseMessage()+"is a broken link");
            }  
            else{
                System.out.println(linkUrl+" - "+httpURLConnect.getResponseMessage());
            }
        }catch (Exception e) {
        }

	}

}
